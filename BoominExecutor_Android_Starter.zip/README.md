# BOOMIN EXECUTOR — Android starter project

A standalone Android Luau editor prototype with a draggable floating launcher, local script storage, and a local-preview console.

## Safety and scope
This project is an editor and script organizer. The TEST button only reports local editor information; it does not execute code in Roblox, inject into the Roblox client, or bypass Roblox security.

## Build on Windows
1. Install Android Studio and a compatible JDK (Android Studio's bundled JBR is fine).
2. Open this folder in Android Studio.
3. Allow Gradle sync to finish.
4. Connect an Android phone with USB debugging enabled, or use an emulator.
5. Press Run to install the app.
6. In the app, tap **GRANT OVERLAY PERMISSION** and enable **Display over other apps**.
7. Return to BOOMIN EXECUTOR and tap **START FLOATING EDITOR**.
8. Tap the blue B bubble to open/minimize the editor.

## Build an APK
In Android Studio choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
The debug APK is normally created at:
`app/build/outputs/apk/debug/app-debug.apk`

## Notes
- The overlay service is started by a visible user action and displays an ongoing notification.
- Android may require you to allow the overlay permission in system settings.
- This starter intentionally keeps TEST as a local preview rather than a code execution engine.
- For a release build, create a signing key in Android Studio's Generate Signed Bundle / APK wizard.
