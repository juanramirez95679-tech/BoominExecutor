package com.boomin.executor

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class FloatingService : Service() {
    private lateinit var windowManager: WindowManager
    private var bubble: View? = null
    private var panel: View? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private var output: TextView? = null
    private var editor: EditText? = null

    private val navy = Color.rgb(7, 10, 16)
    private val panelColor = Color.rgb(17, 24, 36)
    private val blue = Color.rgb(22, 139, 255)
    private val white = Color.WHITE
    private val prefs by lazy { getSharedPreferences("boomin_scripts", MODE_PRIVATE) }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotification()
        showBubble()
    }

    private fun createNotification() {
        val channelId = "boomin_overlay"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId, "BOOMIN floating editor", NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val notification = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, channelId)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }.setContentTitle("BOOMIN EXECUTOR")
            .setContentText("Floating Luau editor is active")
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .setOngoing(true)
            .build()
        startForeground(41, notification)
    }

    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    private fun baseParams(width: Int, height: Int) =
        WindowManager.LayoutParams(
            width, height, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }

    private fun showBubble() {
        if (bubble != null) return
        val b = TextView(this).apply {
            text = "B"
            textSize = 22f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(white)
            setBackgroundColor(blue)
            elevation = 12f
            setOnClickListener { togglePanel() }
        }
        val params = baseParams(dp(58), dp(58)).apply {
            x = dp(14); y = dp(180)
        }
        makeDraggable(b, params)
        bubble = b
        windowManager.addView(b, params)
    }

    private fun togglePanel() {
        if (panel == null) showPanel() else hidePanel()
    }

    private fun showPanel() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(navy)
            elevation = 18f
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = TextView(this).apply {
            text = "BOOMIN EXECUTOR"
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(white)
        }
        val minimize = smallButton("—") { hidePanel() }
        val close = smallButton("×") { stopSelf() }
        header.addView(title, LinearLayout.LayoutParams(0, dp(42), 1f))
        header.addView(minimize, LinearLayout.LayoutParams(dp(42), dp(42)))
        header.addView(close, LinearLayout.LayoutParams(dp(42), dp(42)))
        root.addView(header)

        val tab = TextView(this).apply {
            text = "EDITOR   •   LOCAL SCRIPTS"
            textSize = 10f
            setTextColor(blue)
            setPadding(0, dp(8), 0, dp(8))
        }
        root.addView(tab)

        val code = EditText(this).apply {
            setText(prefs.getString("last_script", "-- BOOMIN EXECUTOR\nprint(\"Hello Boomin!\")"))
            setTextColor(Color.rgb(190, 220, 255))
            setHintTextColor(Color.GRAY)
            hint = "Write Luau code here..."
            textSize = 12f
            typeface = Typeface.MONOSPACE
            gravity = Gravity.TOP or Gravity.START
            setPadding(dp(10), dp(10), dp(10), dp(10))
            setBackgroundColor(panelColor)
            minLines = 9
            maxLines = 14
        }
        editor = code
        root.addView(code, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(220)
        ))

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        actions.addView(smallButton("SAVE") {
            prefs.edit().putString("last_script", editor?.text?.toString().orEmpty()).apply()
            setOutput("Saved locally on this device.")
        }, LinearLayout.LayoutParams(0, dp(42), 1f))
        actions.addView(smallButton("TEST") {
            val text = editor?.text?.toString().orEmpty()
            val lines = text.lines().size
            setOutput("Local preview only: $lines lines loaded.\nNo Roblox execution was performed.")
        }, LinearLayout.LayoutParams(0, dp(42), 1f))
        actions.addView(smallButton("CLEAR") {
            editor?.setText("")
            setOutput("Editor cleared.")
        }, LinearLayout.LayoutParams(0, dp(42), 1f))
        root.addView(actions)

        val consoleLabel = TextView(this).apply {
            text = "OUTPUT CONSOLE"
            textSize = 10f
            setTextColor(blue)
            setPadding(0, dp(10), 0, dp(5))
        }
        root.addView(consoleLabel)
        output = TextView(this).apply {
            text = "Console ready."
            textSize = 11f
            setTextColor(Color.rgb(150, 220, 170))
            setPadding(dp(9), dp(8), dp(9), dp(8))
            setBackgroundColor(panelColor)
        }
        root.addView(output, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(54)
        ))

        val scroll = ScrollView(this).apply { addView(root) }
        val params = baseParams(dp(320), dp(430)).apply {
            x = dp(12); y = dp(100)
            flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        }
        panel = scroll
        panelParams = params
        windowManager.addView(scroll, params)
    }

    private fun setOutput(message: String) {
        output?.text = message
    }

    private fun hidePanel() {
        panel?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
        }
        panel = null
        panelParams = null
        editor = null
        output = null
    }

    private fun smallButton(label: String, action: () -> Unit) =
        Button(this).apply {
            text = label
            textSize = 10f
            isAllCaps = false
            setTextColor(white)
            setBackgroundColor(panelColor)
            setOnClickListener { action() }
        }

    private fun makeDraggable(view: View, params: WindowManager.LayoutParams) {
        var startX = 0
        var startY = 0
        var downX = 0f
        var downY = 0f
        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x; startY = params.y
                    downX = event.rawX; downY = event.rawY
                    false
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX + (event.rawX - downX).toInt()
                    params.y = startY + (event.rawY - downY).toInt()
                    try { windowManager.updateViewLayout(view, params) } catch (_: Exception) {}
                    true
                }
                else -> false
            }
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        hidePanel()
        bubble?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
        }
        bubble = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
